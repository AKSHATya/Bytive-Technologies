// controllers/taskController.js

import db from '../db/db.js';

// Add a new task
export const addTask = async (req, res) => {
    try {
        const { title, description, status } = req.body;
        await db.query(
            `INSERT INTO tasks (title, description, status) VALUES ($1, $2, $3)`,
            [title, description, status]
        );
        res.status(201).json({ message: 'Task created successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get all tasks
export const getTasks = async (req, res) => {
    try {
        const { rows } = await db.query('SELECT * FROM tasks');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Get task by ID
export const getTaskById = async (req, res) => {
    try {
        const { id } = req.params;
        const { rows } = await db.query('SELECT * FROM tasks WHERE id = $1', [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: 'Task not found' });
        }
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Update task status
export const updateTask = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        await db.query('UPDATE tasks SET status = $1 WHERE id = $2', [status, id]);
        res.json({ message: 'Task updated successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete a task
export const deleteTask = async (req, res) => {
    try {
        const { id } = req.params;
        await db.query('DELETE FROM tasks WHERE id = $1', [id]);
        res.json({ message: 'Task deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
