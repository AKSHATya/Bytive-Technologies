// routes/taskRoutes.js

import express from 'express';
import { addTask, getTasks, getTaskById, updateTask, deleteTask } from '../controllers/taskController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/tasks', authenticate, addTask);
router.get('/tasks', authenticate, getTasks);
router.get('/tasks/:id', authenticate, getTaskById);
router.put('/tasks/:id', authenticate, updateTask);
router.delete('/tasks/:id', authenticate, deleteTask);

export default router;
